    <footer>
        <p>&copy; Universitas Pelita Bangsa 2022 - Raden Kodrat - 312010271 - TI.20.D.1</p>
    </footer>
</div>
</body>
</html>
