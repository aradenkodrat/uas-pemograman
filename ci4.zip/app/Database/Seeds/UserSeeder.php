<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
	public function run()
	{
		$model = model('UserModel');
		$model->insert([
			'username' => 'radenkodrat',
			'useremail' => 'radenkodrat23@gmail.com',
			'userpassword' => 'radenkodrat', PASSWORD_DEFAULT),
	]);
}
}